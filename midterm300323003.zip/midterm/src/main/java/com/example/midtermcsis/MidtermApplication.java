package com.example.midtermcsis;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;
import org.springframework.web.bind.annotation.RestController;

@SpringBootApplication
@RestController
public class MidtermApplication {

	public static void main(String[] args) {

		SpringApplication.run(MidtermApplication.class, args);
	}

}
